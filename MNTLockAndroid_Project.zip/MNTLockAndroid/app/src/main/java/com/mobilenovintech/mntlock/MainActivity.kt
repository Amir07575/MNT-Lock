package com.mobilenovintech.mntlock

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.AEADBadTagException
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class MainActivity : Activity() {
    private lateinit var password: EditText
    private lateinit var status: TextView
    private lateinit var encryptButton: Button
    private lateinit var decryptButton: Button
    private var pendingInput: Uri? = null
    private var pendingMode: Mode? = null

    private enum class Mode { ENCRYPT, DECRYPT }
    private val pickEncrypt = 101
    private val saveEncrypted = 102
    private val pickDecrypt = 103
    private val saveDecrypted = 104

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(20))
            setBackgroundColor(Color.rgb(19, 22, 29))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val title = TextView(this).apply {
            text = "MNT LOCK"
            textSize = 29f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "رمزگذاری و بازیابی امن فایل‌ها"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(24))
        }
        root.addView(subtitle, matchWrap())

        val label = TextView(this).apply {
            text = "رمز عبور"
            textSize = 15f
            setTextColor(Color.WHITE)
        }
        root.addView(label, matchWrap())

        password = EditText(this).apply {
            hint = "یک رمز قوی وارد کن"
            textSize = 16f
            setSingleLine(true)
            inputType = 129 // textPassword
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(Color.rgb(42, 47, 58))
        }
        val passParams = matchWrap()
        passParams.topMargin = dp(8)
        passParams.bottomMargin = dp(20)
        root.addView(password, passParams)

        encryptButton = makeButton("🔒  انتخاب فایل و رمزگذاری")
        root.addView(encryptButton, buttonParams())
        encryptButton.setOnClickListener {
            if (!validatePassword()) return@setOnClickListener
            pendingMode = Mode.ENCRYPT
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }, pickEncrypt)
        }

        decryptButton = makeButton("🔓  انتخاب فایل رمزدار و بازیابی")
        root.addView(decryptButton, buttonParams())
        decryptButton.setOnClickListener {
            if (!validatePassword()) return@setOnClickListener
            pendingMode = Mode.DECRYPT
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }, pickDecrypt)
        }

        status = TextView(this).apply {
            text = "فایل‌ها فقط روی گوشی پردازش می‌شوند؛ اینترنت لازم نیست."
            textSize = 14f
            setTextColor(Color.rgb(190, 197, 210))
            gravity = Gravity.CENTER
            setPadding(0, dp(22), 0, dp(12))
        }
        root.addView(status, matchWrap())

        val note = TextView(this).apply {
            text = "هشدار: اگر رمز را فراموش کنی، بازیابی فایل ممکن نیست. رمزت را در جای امن نگه دار."
            textSize = 12f
            setTextColor(Color.rgb(255, 190, 120))
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(16), dp(8), 0)
        }
        root.addView(note, matchWrap())
        setContentView(root)
    }

    private fun validatePassword(): Boolean {
        val p = password.text.toString()
        if (p.length < 8) {
            status.text = "رمز عبور باید حداقل ۸ کاراکتر باشد."
            return false
        }
        return true
    }

    private fun makeButton(textValue: String) = Button(this).apply {
        text = textValue
        textSize = 15f
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(222, 105, 30))
        minimumHeight = dp(54)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun buttonParams() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, dp(58)
    ).apply { bottomMargin = dp(12) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @Deprecated("Legacy SAF result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            pickEncrypt -> {
                pendingInput = uri
                val name = "encrypted_file.mntlock"
                startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/octet-stream"
                    putExtra(Intent.EXTRA_TITLE, name)
                }, saveEncrypted)
            }
            saveEncrypted -> process(pendingInput, uri, Mode.ENCRYPT)
            pickDecrypt -> {
                pendingInput = uri
                startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/octet-stream"
                    putExtra(Intent.EXTRA_TITLE, "decrypted_file")
                }, saveDecrypted)
            }
            saveDecrypted -> process(pendingInput, uri, Mode.DECRYPT)
        }
    }

    private fun process(input: Uri?, output: Uri, mode: Mode) {
        if (input == null) return
        encryptButton.isEnabled = false
        decryptButton.isEnabled = false
        status.text = "در حال پردازش..."
        val pass = password.text.toString().toCharArray()

        Thread {
            try {
                contentResolver.openInputStream(input).use { rawIn ->
                    requireNotNull(rawIn) { "خواندن فایل ورودی ممکن نشد." }
                    contentResolver.openOutputStream(output, "wt").use { rawOut ->
                        requireNotNull(rawOut) { "ساخت فایل خروجی ممکن نشد." }
                        if (mode == Mode.ENCRYPT) encrypt(rawIn, rawOut, pass)
                        else decrypt(rawIn, rawOut, pass)
                        rawOut.flush()
                    }
                }
                runOnUiThread { status.text = if (mode == Mode.ENCRYPT)
                    "رمزگذاری انجام شد. فایل با پسوند mntlock ذخیره شد."
                else "رمزگشایی انجام شد. فایل بازیابی شد." }
            } catch (e: Exception) {
                try { contentResolver.delete(output, null, null) } catch (_: Exception) {}
                val msg = when (e) {
                    is AEADBadTagException -> "رمز اشتباه است یا فایل دستکاری/خراب شده."
                    else -> e.message ?: "خطای ناشناخته"
                }
                runOnUiThread { status.text = "خطا: $msg" }
            } finally {
                pass.fill('\u0000')
                runOnUiThread {
                    encryptButton.isEnabled = true
                    decryptButton.isEnabled = true
                }
            }
        }.start()
    }

    private fun deriveKey(password: CharArray, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(password, salt, 310_000, 256)
        return try {
            val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                .generateSecret(spec).encoded
            SecretKeySpec(bytes, "AES")
        } finally { spec.clearPassword() }
    }

    private fun encrypt(input: java.io.InputStream, output: java.io.OutputStream, pass: CharArray) {
        val salt = ByteArray(16)
        val iv = ByteArray(12)
        SecureRandom().nextBytes(salt)
        SecureRandom().nextBytes(iv)
        output.write(MAGIC)
        output.write(salt)
        output.write(iv)

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, deriveKey(pass, salt), GCMParameterSpec(128, iv))
        val buffer = ByteArray(64 * 1024)
        while (true) {
            val n = input.read(buffer)
            if (n < 0) break
            val encrypted = cipher.update(buffer, 0, n)
            if (encrypted != null) output.write(encrypted)
        }
        output.write(cipher.doFinal())
    }

    private fun decrypt(input: java.io.InputStream, output: java.io.OutputStream, pass: CharArray) {
        val magic = ByteArray(MAGIC.size)
        readFully(input, magic)
        if (!magic.contentEquals(MAGIC)) throw IllegalArgumentException("این فایل، فایل MNT Lock معتبر نیست.")
        val salt = ByteArray(16)
        val iv = ByteArray(12)
        readFully(input, salt)
        readFully(input, iv)

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, deriveKey(pass, salt), GCMParameterSpec(128, iv))
        val buffer = ByteArray(64 * 1024)
        while (true) {
            val n = input.read(buffer)
            if (n < 0) break
            val plain = cipher.update(buffer, 0, n)
            if (plain != null) output.write(plain)
        }
        // GCM verifies the authentication tag here; never trust output before this succeeds.
        output.write(cipher.doFinal())
    }

    private fun readFully(input: java.io.InputStream, data: ByteArray) {
        var offset = 0
        while (offset < data.size) {
            val n = input.read(data, offset, data.size - offset)
            if (n < 0) throw IllegalArgumentException("فایل ناقص یا خراب است.")
            offset += n
        }
    }

    companion object {
        private val MAGIC = "MNTLOCK1".toByteArray(Charsets.US_ASCII)
    }
}
